import os
from getpass import getpass
os.system('color 9f')
intro='----'*27+'\n\t\t\t\t\t\tGAME STATION\n'+'----'*27+'\nMENU Lists :'+'\n----------\n\n1.Login(If your are already registered)\n2.Register(If you are a new user only !!)'
print(intro)
while True:
    op=input('Enter your Option -->')
    if op=='1':
        print('\nEnter your Username :',end='')
        global n
        n=input().lower()
        if (n+'.txt' in os.listdir('.\\login')):
            p=getpass('Enter your password : ')
            file=open('.\\login\\'+n+'.txt')
            text=file.read()
            file.close()
            if '\t'+p+'\n' in text:
                print('\aWelcome to the \"GAME STATION\"',n)
                print('\n\tPress ENTER key to proceed . . .')
                test=input()
                #os.system('cls')
                #os.system('select.py')
                os.system('cls')
                #print('\a'+intro)
                break
            else:
                print('Invalid Password . . . !!!\n\t(Press ENTER key to proceed . . .)')
                test=input()
                os.system('cls')
                print(intro)
                continue
        else:
            print('\tInvalid Username ! ! ! Please go register yourself\n\t(Press ENTER key to proceed . . .)')
            test=input()
            os.system('cls')
            print(intro)
    elif op=='2':
        print('\nEnter your Username :',end='')
        n=input().lower()
        text=os.listdir('.\\login')
        if (n+'.txt' in text) or n.isspace() or n=='':
            print('\a\n\tUsername already exists, Enter a new username  !!\n\t(Press ENTER key to proceed . . .)')
            test=input()
            os.system('cls')
            print(intro)
            continue
        p=getpass('Enter your password : ')
        c=0
        for i in p:
            if (i.isalnum() or ('@' in p)) and (i.isspace()==False):
                c+=1
        if(c==len(p))  and p!='':
            file=open('.\\login\\'+n+'.txt','w')
            file.write(n+'\t'*3+p+'\n')
            file.close()
            print('\nYou are successfully registered '+n+' !!\n\t(Press ENTER key to Proceed . . .)')
            test=input()
            os.system('cls')
            print(intro)
            
        else:
            print('\a\n\t\tInvalid password format.\n\t\t(Use Alphabets,numbers and \'@\' only)\n\t(Press any key to Proceed . . .)')
            test=input()
            os.system('cls')
            print(intro)
            continue
    else:
        print('Invalid option\a\n\t(Press ENTER key to Proceed . . .)')
        test=input()
        os.system('cls')
        print(intro)
        continue
sintro='\nSELECTION Menu Lists :\n'+'-'*20+'\n\n1.TicTac Game\n2.Quiz Game\n3.Exit'
while True:
    print(sintro+'\nEnter you option : -->',end='')
    op=input()
    if op=='1':
        os.system('cls')
        print('\t\t\t<< '+n+' \awelcome to \"TicTac Game\" >>\n\n')
        file=open('cache.txt','w')
        file.write(n)
        file.close()
        os.system('tictoc.py')
        os.system('cls')
        print(sintro)
    elif op=='2':
        os.system('cls')
        print('\t\t\t<<'+n+' \awelcome to \"Quiz Game\" >>\n\n')
        file=open('cache.txt','w')
        file.write(n)
        file.close()
        os.system('quiz.py')
        os.system('cls')
        print(sintro)
    elif op=='3':
        os.system('color e9')
        os.system('cls')
        if n+'.txt' in os.listdir('.\\feedback'):
            print('\n\n\tHey '+n+', we are glad to see your Re-participation in our \"Game Station\"')
            print('\tlet\'s get to know about your new experience in your Game Station Journey(Type what you feel about this game :) ) : \n')
            feed=input('FEEDBACK  :  ')
            file=open('.\\feedback\\'+n+'.txt','a')
            file.write('Feed: \" '+feed+' \"\n')
            file.close()
            break
        else:
            print('\n\n\t'+n+', we are glad to see your participation in our \"Game Station\"')
            print('\tWhat is your takeaway on our Game Station(Type what you feel about this game :) ) : \n')
            feed=input('FEEDBACK  :  ')
            if feed=='' or feed.isspace():
                print('Your feedback would help us to improve our Game Station in better way, you can skip this part by clicking ENTER key in keyboard\n')
                feed=input('FEEDBACK  :  ')
            file=open('.\\feedback\\'+n+'.txt','w')
            file.write('Feed: \" '+feed+' \"\n')
            file.close()
            break
    else:
        print('\tInvalid option ! ! !\a\n\t(Press ENTER key to Proceed . . .)')
        test=input()
        os.system('cls')
        continue
