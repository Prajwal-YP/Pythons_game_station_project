import os
import sys
import random
d={'tl':' ','tm':' ','tr':' ','ml':' ','mm':' ','mr':' ','ll':' ','lm':' ','lr':' '}
file=open('cache.txt')
n=file.read()
file.close()

def feedback():
    os.system('cls')
    os.system('color e9')
    print('Hey '+n+', can you please type_in how was this Tic-Tac Game below in the feedback section . . .\n\n')
    f=input('FEEDBACK ON \" Tic-Toc \"  :  ')
    if n+'.txt' in os.listdir('.\\feedbackt'):
        file=open('.\\feedbackt\\'+n+'.txt','a')
        file.write('Feed: \" '+f+' \"\n')
        file.close()
        os.system('color 9f')
    else:
        file=open('.\\feedbackt\\'+n+'.txt','w')
        file.write('Feed: \" '+f+' \"\n')
        file.close()
        os.system('color 9f')
def dis():
    print('TICTOC BOARD : \n')
    print('\t\t'+'----'*16+'-')
    print('\t\t'+'|\t\t\t\t'+d['tl']+'|'+d['tm']+'|'+d['tr']+'\t\t\t\t|'+'\n\t\t|\t\t\t\t-+-+-\t\t\t\t|')
    print('\t\t'+'|\t\t\t\t'+d['ml']+'|'+d['mm']+'|'+d['mr']+'\t\t\t\t|'+'\n\t\t|\t\t\t\t-+-+-\t\t\t\t|')
    print('\t\t'+'|\t\t\t\t'+d['ll']+'|'+d['lm']+'|'+d['lr']+'\t\t\t\t|')
    print('\t\t'+'----'*16+'-')

def iseq(a):
    if (d['tl']==d['tm']==d['tr']==a) or (d['ml']==d['mm']==d['mr']==a) or (d['ll']==d['lm']==d['lr']==a) or (d['tl']==d['ml']==d['ll']==a) or (d['tm']==d['mm']==d['lm']==a) or (d['tr']==d['mr']==d['lr']==a) or (d['tl']==d['mm']==d['lr']==a) or (d['tr']==d['mm']==d['ll']==a):
        print('Game Finished\n'+'----'*27)
        if a=='X':
            print('\t\t\t\tWinner = \"'+n+'\"')
            print('----'*27)
            goto=input('Press \" ENTER key \" to proceed . . .')
            
        else:
            print('\t\t\t\tWinner = Computer')
            print('----'*27)
            goto=input('Press \" ENTER key \" to proceed . . .')
        return 1
dis()
turn='X'
def location():
    print('Locations are :')
    print('\t\t'+'----'*18+'-\n\t\t|\t\t\t\ttl|tm|tr\t\t\t\t|\n\t\t|\t\t\t\t--+--+--\t\t\t\t|\n\t\t|\t\t\t\tml|mm|mr\t\t\t\t|\n\t\t|\t\t\t\t--+--+--\t\t\t\t|\n\t\t|\t\t\t\tll|lm|lr\t\t\t\t|'+'\n\t\t'+'----'*18+'-\n')
location()
while (' ' in d.values()):
    while True:
        if turn=='X':
            print('\n\t',n,'where do you want to enter \'X\' mark : ',end='')
            loc=input()
        else:
                #--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                if ' ' in d['mm']:
                    loc='mm'
                elif ( (('O' in d['tl'])and('O' in d['mm'])) or (('O' in d['tl'])and('O' in d['lr'])) or (('O' in d['mm'])and('O' in d['lr'])) ) and ( ' ' in (d['tl'],d['mm'],d['lr']) ):
                    loc=random.choice(['tl','mm','lr'])
                elif ( (('O' in d['tr'])and('O' in d['mm'])) or (('O' in d['mm'])and('O' in d['ll'])) or (('O' in d['tr'])and('o' in d['ll'])) ) and ( ' ' in (d['tr'],d['mm'],d['ll']) ):
                      loc=random.choice(['tr','mm','ll'])
                elif ( (('o' in d['tl'])and('O' in d['tm'])) or (('O' in d['tl'])and('O' in d['tr'])) or (('O' in d['tm'])and('O' in d['tr'])) ) and ( ' ' in (d['tl'],d['tm'],d['tr']) ):
                      loc=random.choice(['tl','tm','tr'])
                elif ( (('O' in d['tl'])and('O' in d['ml'])) or (('O' in d['ml'])and('O' in d['ll'])) or (('O' in d['tl'])and('O' in d['ll'])) ) and ( ' ' in (d['tl'],d['ml'],d['ll']) ):
                      loc=random.choice(['tl','ml','ll'])
                elif ( (('O' in d['tm'])and('O' in d['mm'])) or (('O' in d['mm'])and('O' in d['lm'])) or (('O' in d['tm'])and('O' in d['lm'])) ) and ( ' ' in (d['tm'],d['mm'],d['lm']) ):
                      loc=random.choice(['tm','mm','lm'])
                elif ( (('O' in d['tr'])and('O' in d['mr'])) or (('O' in d['mr'])and('O' in d['lr'])) or (('O' in d['tr'])and('O' in d['lr'])) ) and ( ' ' in (d['tr'],d['mr'],d['lr']) ):
                      loc=random.choice(['tr','mr','lr'])
                elif ( (('O' in d['ml'])and('O' in d['mm'])) or (('O' in d['mm'])and('O' in d['mr'])) or (('O' in d['mr'])and('O' in d['ml'])) ) and ( ' ' in (d['ml'],d['mm'],d['mr']) ):
                    loc=random.choice(['ml','mm','mr'])
                elif ( (('O' in d['ll'])and('O' in d['lm'])) or (('O' in d['lm'])and('O' in d['lr'])) or (('O' in d['lr'])and('O' in d['ll'])) ) and ( ' ' in (d['ll'],d['lm'],d['lr']) ):
                    loc=random.choice(['ll','lm','lr'])
                #--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                elif ( (('X' in d['tl'])and('X' in d['mm'])) or (('X' in d['tl'])and('X' in d['lr'])) or (('X' in d['mm'])and('X' in d['lr'])) ) and ( ' ' in (d['tl'],d['mm'],d['lr']) ):
                    loc=random.choice(['tl','mm','lr'])
                elif ( (('X' in d['tr'])and('X' in d['mm'])) or (('X' in d['mm'])and('X' in d['ll'])) or (('X' in d['tr'])and('X' in d['ll'])) ) and ( ' ' in (d['tr'],d['mm'],d['ll']) ):
                      loc=random.choice(['tr','ml','ll'])
                elif ( (('X' in d['tl'])and('X' in d['tm'])) or (('X' in d['tl'])and('X' in d['tr'])) or (('X' in d['tm'])and('X' in d['tr'])) ) and ( ' ' in (d['tl'],d['tm'],d['tr']) ):
                      loc=random.choice(['tl','tm','tr'])
                elif ( (('X' in d['tl'])and('X' in d['ml'])) or (('X' in d['ml'])and('X' in d['ll'])) or (('X' in d['tl'])and('X' in d['ll'])) ) and ( ' ' in (d['tl'],d['ml'],d['ll']) ):
                      loc=random.choice(['tl','ml','ll'])
                elif ( (('X' in d['tm'])and('X' in d['mm'])) or (('X' in d['mm'])and('X' in d['lm'])) or (('X' in d['tm'])and('X' in d['lm'])) ) and ( ' ' in (d['tm'],d['mm'],d['lm']) ):
                      loc=random.choice(['tm','mm','lm'])
                elif ( (('X' in d['tr'])and('X' in d['mr'])) or (('X' in d['mr'])and('X' in d['lr'])) or (('X' in d['tr'])and('X' in d['lr'])) ) and ( ' ' in (d['tr'],d['mr'],d['lr']) ):
                      loc=random.choice(['tr','mr','lr'])
                elif ( (('X' in d['ml'])and('X' in d['mm'])) or (('X' in d['mm'])and('X' in d['mr'])) or (('X' in d['mr'])and('X' in d['ml'])) ) and ( ' ' in (d['ml'],d['mm'],d['mr']) ):
                    loc=random.choice(['ml','mm','mr'])
                elif ( (('X' in d['ll'])and('X' in d['lm'])) or (('X' in d['lm'])and('X' in d['lr'])) or (('X' in d['lr'])and('X' in d['ll'])) ) and ( ' ' in (d['ll'],d['lm'],d['lr']) ):
                    loc=random.choice(['ll','lm','lr'])
               #--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                elif ('X' in d['mm']) and ('X' in d['ll']) and ('O' in d['tr']) and (' ' in (d['tl'],d['lr']) ):
                    if (' ' in d['tm']) and (' ' in d['tl']):
                        loc='tl'
                    elif ' ' in d['lr']:
                        loc='lr'
                    else:
                        random.choice(['tl','lr'])
                elif ('X' in d['mm']) and ('O' in d['ll']) and ('X' in d['tr']) and (' ' in (d['tl'],d['lr']) ):
                    if (' ' in d['lm']) and (' ' in d['lr']):
                        loc='lr'
                    elif ' ' in d['tl']:
                        loc='tl'
                    else:
                        random.choice(['tl','lr'])
                elif ('X' in d['mm']) and ('X' in d['lr']) and ('O' in d['tl']) and (' ' in (d['tr'],d['ll']) ):
                    if (' ' in d['tm']) and (' ' in d['tr']):
                        loc='tr'
                    elif ' ' in d['ll']:
                        loc='ll'
                    else:
                        random.choice(['tr','ll'])
                elif ('X' in d['mm']) and ('O' in d['lr']) and ('X' in d['tl']) and (' ' in (d['tr'],d['ll']) ):
                    if (' ' in d['lm']) and (' ' in d['ll']):
                        loc='ll'
                    elif ' ' in d['tr']:
                        loc='tr'
                    else:
                        random.choice(['tr','ll'])
               #--------------------------------------------------------------------------------------------------------------------------------------------------------------------------         
                elif ('X' in d['tr']) and ( ' ' in (d['tl'],d['lr'])):
                    if ('X' in d['ml']) and (' ' in d['tl']):
                        loc='tl'
                    elif ('X' in d['lm']) and (' ' in d['lr']):
                        loc='lr'
                    elif ' ' in d['ml']:
                        loc='ml'
                    else:
                        random.choice(['tl','lr'])
                elif ('X' in d['tl']) and ( ' ' in (d['tr'],d['ll'])):
                    if ('X' in d['mr']) and (' ' in d['tr']):
                        loc='tr'
                    elif ('X' in d['lm']) and (' ' in d['ll']):
                        loc='ll'
                    elif ' ' in d['mr']:
                        loc='mr'
                    else:
                        random.choice(['tr','ll'])
                elif ('X' in d['ll']) and ( ' ' in (d['tl'],d['lr'])):
                    if ('X' in d['tm']) and (' ' in d['tl']):
                        loc='tl'
                    elif ('X' in d['mr']) and (' ' in d['lr']):
                        loc='lr'
                    elif ' ' in d['mr']:
                        loc='mr'
                    else:
                        random.choice(['tl','lr'])
                elif ('X' in d['lr']) and ( ' ' in (d['tr'],d['ll'])):
                    if ('X' in d['tm']) and (' ' in d['tr']):
                        loc='tr'
                    elif ('X' in d['ml']) and (' ' in d['ll']):
                        loc='ll'
                    elif ' ' in d['ml']:
                        loc='ml'
                    else:
                        random.choice(['tr','ll'])
                elif ( ' ' in (d['tl'],d['ll'],d['tr'],d['lr']) ):
                    loc=random.choice(['tl','tr','ll','lr'])    
                #--------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                elif (('X' in d['tm']) and ('X' in d['mr']) and (' ' in d['tr'])):
                    loc='tr'
                elif (('X' in d['tm']) and ('X' in d['ml']) and (' ' in d['tl'])):
                    loc='tl'
                elif (('X' in d['lm']) and ('X' in d['mr']) and (' ' in d['lr'])):
                    loc='lr'
                elif (('X' in d['lm']) and ('X' in d['ml']) and (' ' in d['ll'])):
                    loc='ll'
                else:
                    loc=random.choice(['tl','tm','tr','ml','mm','mr','ll','lm','lr'])
                #--------------------------------------------------------------------------------------------------------------------------------------------------------------------------    
                if d[loc]==' ':
                    print('\t\t( Computer marks \"O\" on location \"'+loc+'\" )')    
        try:
            if d[loc]!=' ':
                if turn=='X':
                    print('This location is already marked as %s.. !!!\n' % d[loc])
                    location()
                continue
            break
        except:
            print('Location do not exist(Invalid Location !!). Refer these location names below\n')
            location()
            continue
    d[loc]=turn
    dis()
    a=iseq(turn)
    if a==1:
        break
    elif turn=='X':
        turn='O'
    else:
        turn='X'
if a!=1:
    print('Game Finished\n'+'------'*10)
    print('Draw Match ....!!!')
    goto=input('Enter any key to proceed')
feedback()
