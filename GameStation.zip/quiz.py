import os

#Take name :
file=open('cache.txt')
n=file.read()
file.close()

#take feedback
def feedback():
    os.system('cls')
    os.system('color e9')
    print('Heyyy!!! '+n+' please tell us how was the Quiz,also let us know if you have any tricky quiz up on your sleve too in the  below Feedback section below . . .\n\n')
    f=input('FEEDBACK  :  ')
    if n+'.txt' in os.listdir('.\\feedbackq'):
        file=open('.\\feedbackq\\'+n+'.txt','a')
        file.write('Feed: \" '+f+' \"\n')
        file.close()
        os.system('color 9f')
    else:
        file=open('.\\feedbackq\\'+n+'.txt','w')
        file.write('Feed: \" '+f+' \"\n')
        file.close()
        os.system('color 9f')

#variables
x=0

#Questions
q1='1.Python was introduced in the year\n\t\t\ta.1991\t\t\tb.1990\n\t\t\tc.2001\t\t\td.2005'
q2='2. Who is the inventor of Computer\n\t\t\ta.John Wick\t\t\tb.Charles Babbage\n\t\t\tc.Coluson\t\t\td.Prof. Salva'
q3='3. Which is the largest planet\n\t\t\ta.Saturn\t\t\tb.Uranus\n\t\t\tc.Pluto\t\t\t\td.Jupiter'
q4='4. Which is the smallest country in the world\n\t\t\ta.New Zeland\t\t\tb.Green Land\n\t\t\tc.Vatican City\t\t\td.Maldives'
q5='5. Which is the largest TENDER COCONUT market in the World\n\t\t\ta.Banglore\t\t\tb.Maddur\n\t\t\tc.Tumkur\t\t\td.coimbatore'
q6='6. Who is the founder of Microsoft\n\t\t\ta.Bill gates\t\t\tb.Mark Zukerberg\n\t\t\tc.Paul Allen\t\t\td.Satya Nadella '
q7='7. Who is the father of Artificial Inteligence\n\t\t\ta.John McCarthy\t\t\tb.Alan Turing\n\t\t\tc.Ray Kurzweil\t\t\td.Geoffrey Hinton'
q8='8.How many Bits are there in \"int data type\" in \'64-bit machine\'?\n\t\t\ta.4\t\t\tb.8\n\t\t\tc.16\t\t\td.32'
q9='9.The process to find error in a software code is called?\n\t\t\ta.Debugging\t\t\tb.Testing\n\t\t\tc.Automation\t\t\td.Comipilation'
q10='10.Data that is copied from an application is stored in?\n\t\t\ta.Flah Memory\t\t\tb.Hard Disk\n\t\t\tc.ClipBoard\t\t\td.Ram'

#answeres
cs={q1:['a','1991'],q2:['b','Charles Babbage'],q3:['d','Jupiter'],q4:['c','Vatican City'],q5:['b','Maddur'],q6:['a','Bill gates'],q7:['a','John McCarthy'],q8:['d','32'],q9:['a','Debugging'],q10:['c','ClipBoard']}
ws={}

#input
for question in cs.keys():
    print(question)
    while True:
        option=input('Answer --> ').lower()
        if option in ('a' , 'b' , 'c' , 'd'):
            break
        else:
            print('\t\t\aInvalid Option !!')
    print('----'*27)
    if option!=cs[question][0]:
        ws[question]=cs[question]
        x+=1

#output
print('\t\tYour Score is '+str(10-x)+'0% ('+str(10-x)+'/10 Marks)\n'+'----'*27)
option=input('Do you want to display the correct answers for the \" '+str(x)+' incorrect answers \"  :  ').lower()
if 'y' in option:
    for question in ws.keys():
        print('\n'+question+'\nAnswer -> ('+ws[question][0]+')'+ws[question][1])
print('----'*27+'\n'+'\t\tThank you for participating in Quiz'+'\n'+'----'*27)
print('\t\t\tPress \" ENTER key \" to Proceed . . .')
test=input()
feedback()
